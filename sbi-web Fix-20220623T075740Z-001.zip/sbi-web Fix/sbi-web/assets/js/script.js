$(document).ready(function () {
    // Untuk scroll yang smooth
    var scroll = new SmoothScroll('.menu-list .menu[href*="#"]', {
        speed: 1500,
        offset: 80,
    });

    var scroll = new SmoothScroll('.other-menu a[href*="#"]', {
        speed: 1500,
        offset: 80,
    });
    // end: Untuk scroll yang smooth


    // Untuk tab menu 
    $('.menu-area .tab').click(function () {
        // inisialisasi nilai tab dari attribut
        var tab_id = $(this).attr('data-tabs');
        // ngehapus class active
        $('.menu-area .tab').removeClass('active');
        $('.tab-content').removeClass('active');

        // nambah class active di tab yang di klik
        $(this).addClass('active');
        $("#" + tab_id).addClass('active');
    });
    // end: Untuk tab menu

    // Untuk header mobile
    $('.header .menu-mobile').click(function () {
        $(this).toggleClass('open');
        $('.header .menu-list').toggleClass('open');
        $('.header .other-menu').toggleClass('open');
    });
})